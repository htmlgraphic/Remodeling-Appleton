<?php
/*
Template Name: Custom Page
*/
?>
<?php get_header(); ?>

		<section></section>

<?php get_footer(); ?>